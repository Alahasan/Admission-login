-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2022 at 08:37 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ssc_admission`
--

-- --------------------------------------------------------

--
-- Table structure for table `ssc_students`
--

CREATE TABLE `ssc_students` (
  `ID` int(11) NOT NULL,
  `stud_name` text NOT NULL,
  `stud_father_name` text NOT NULL,
  `stud_mother_name` text NOT NULL,
  `stud_date_of_birth` date NOT NULL,
  `stud_mobile_no` int(15) NOT NULL,
  `stud_email` varchar(250) NOT NULL,
  `stud_school` text NOT NULL,
  `stud_register_date` date NOT NULL,
  `stud_password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ssc_students`
--

INSERT INTO `ssc_students` (`ID`, `stud_name`, `stud_father_name`, `stud_mother_name`, `stud_date_of_birth`, `stud_mobile_no`, `stud_email`, `stud_school`, `stud_register_date`, `stud_password`) VALUES
(10002, 'Sakib', 'Billal', 'Tanjila', '2005-05-08', 1735985575, 'tanvir@gmail.com', 'DBHS', '2022-06-27', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ssc_students`
--
ALTER TABLE `ssc_students`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `stud_email` (`stud_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ssc_students`
--
ALTER TABLE `ssc_students`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10003;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
